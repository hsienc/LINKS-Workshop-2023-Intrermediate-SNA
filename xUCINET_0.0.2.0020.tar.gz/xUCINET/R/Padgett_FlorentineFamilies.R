#' Network among Florentine families
#'
#' This data contain the social relations among 16 Renaissance Florentine families (person aggregates) coded by John Padgett from historical documents. Breiger & Pattison (1986), in their discussion of local role analysis, use a subset of data. The two relations are business ties and marriage alliances. As Breiger & Pattison point out, the original data are symmetrically coded. This is acceptable perhaps for marital ties, but is unfortunate for the financial ties (which are almost certainly directed). Substantively, the data include families who were locked in a struggle for political control of the city of Florence in around 1430. Two factions were dominant in this struggle: one revolved around the infamous Medicis, the other around the powerful Strozzis.
#'
#' @format A list object (xUCINET project/dataset) containing 2 networks and 3 attributes
#'  \describe{
#'  \item{$ProjectInfo}{ -  Contains a series of elements and descriptions: $ProjectName, $GeneralDescription, $AttributesDescription, $NetworksDescription, $References}
#'  \item{$Attributes}{ -  A data.frame with attributes for nodes}
#'  \item{$NetworkInfo}{ -  A data.frame with additional information about each network: $Name, $Mode, $Directed, $Diagonal, £Values, $Class}
#'  \item{$Strength}{ -  Network1. See $ProjectInfo$NetworksDescription for more information}
#'  \item{$Connection}{ -  Network2. See $ProjectInfo$NetworksDescription for more information}
#'  }
#'
#' @source {UCINET}
#'
#' @examples
#' Padgett_FlorentineFamilies
#'
#' @references {See $ProjectInfo$References}
"Padgett_FlorentineFamilies"
