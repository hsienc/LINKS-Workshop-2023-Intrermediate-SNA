#' ASNR_Fig10x1a
#'
#' This is an example dataset used in Borgatti, Everett, Johnson and Agneessens (2022).
#'
#' @format A network object of class "matrix".
#'
#' @references {Borgatti, Everett, Johnson and Agneessens (2022) Analyzing social networks with R. Sage.}
"ASNR_Fig10x1a"
