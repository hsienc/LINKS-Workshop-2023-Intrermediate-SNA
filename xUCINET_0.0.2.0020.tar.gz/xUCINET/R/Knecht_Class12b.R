#' Network among school kids in a school collected by Knecht.
#'
#' This data was collected in a Dutch school by Andrea Knecht as part of her dissertation (Knecht, 2008). It measures friendship at 4 time points among 26 11-13 year old kids, as well as delinquency and alcohol use (the last was not measured at time 1). It also contains information about whether the kids knew each other from primary education.
#'
#' @format A list object (xUCINET project/dataset) containing 5 networks and 11 attributes
#'  \describe{
#'  \item{$ProjectInfo}{ -  Contains a series of elements and descriptions: $ProjectName, $GeneralDescription, $AttributesDescription, $NetworksDescription, $References}
#'  \item{$Attributes}{ -  A data.frame with attributes for nodes}
#'  \item{$NetworkInfo}{ -  A data.frame with additional information about each network: $Name, $Mode, $Directed, $Diagonal, £Values, $Class}
#'  \item{$Strength}{ -  Network1. See $ProjectInfo$NetworksDescription for more information}
#'  \item{$Connection}{ -  Network2. See $ProjectInfo$NetworksDescription for more information}
#'  }
#'
#' @source {UCINET}
#'
#' @examples
#' Knecht_Class12b
#'
#' @references {See $ProjectInfo$References}
"Knecht_Class12b"

