library(testthat)
library(xUCINET)

test_check("xUCINET")
